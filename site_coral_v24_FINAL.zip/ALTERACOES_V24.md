# Sistema de Gestão Coral - Versão 24

## 📋 Resumo das Alterações

A versão 24 adiciona um **sistema inteligente de sugestões de cânticos** mantendo toda a estrutura e design da v22.

---

## ✨ Novidades da V24

### 🎯 Nova Aba "Sugestões"

Foi adicionada uma nova aba dedicada a sugestões inteligentes de cânticos baseadas no contexto litúrgico.

**Localização na navegação:**
- Página inicial → Programa → **Sugestões** → Catálogo → Histórico → Ensaios

**Características:**
- Mostra resumo litúrgico da data selecionada (tempo, cor, ano, celebração)
- Apresenta até 3 sugestões por parte do programa litúrgico
- Score de relevância visível para cada sugestão
- Informação de uso recente (evita repetições)
- Botões de ação rápida: "Usar" e "Ver letra"

---

## 🧠 Sistema de Pontuação Inteligente

### Como funciona o `scoreSongForContext()`

O sistema atribui pontos a cada cântico baseado em múltiplos critérios:

#### 1. **Adequação à Secção** (40 pontos)
- Verifica se a secção do cântico corresponde à parte do programa
- Exemplos: cântico de "Entrada" para parte "Entrada", "Comunhão" para "Comunhão"

#### 2. **Tempo Litúrgico** (25 pontos)
- Combina o tempo do cântico com o tempo litúrgico do dia
- Advento, Natal, Quaresma, Páscoa, Tempo Comum

#### 3. **Cor Litúrgica** (10 pontos)
- Verifica correspondência com tags da cor (roxo, branco, verde, vermelho)

#### 4. **Palavras-chave Específicas** (10-15 pontos)
- Páscoa: bónus para "Aleluia", "Ressurreição"
- Natal: bónus para "Natal", "Belém"
- Quaresma: bónus para "Conversão", "Quaresma"

#### 5. **Penalização por Uso Recente**
- Menos de 1 semana: **-30 pontos**
- Menos de 1 mês: **-15 pontos**
- Menos de 3 meses: **-5 pontos**

---

## 🎨 Interface Visual

### Informação Litúrgica
```
┌─────────────────────────────────────────────────┐
│ Data: 25/11/2024                                │
│ Celebração: XXXIV Domingo do Tempo Comum       │
│ Tempo: Tempo Comum | Cor: Verde | Ano: B       │
└─────────────────────────────────────────────────┘
```

### Cartão de Sugestão
```
┌─────────────────────────────────────────────────┐
│ 🎉 Entrada                                      │
│ ┌───────────────────────────────────────────┐  │
│ │ Vinde, Cantai ao Senhor                   │  │
│ │ 🎵 J. Silva | 📂 Entrada | Score: 65      │  │
│ │ Usado há 2 meses                          │  │
│ │                            [Usar] [Letra] │  │
│ └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

---

## 🔧 Funcionalidades Técnicas

### Integração com Sistema Existente

1. **Catálogo**: Usa o mesmo array `songs` do Google Sheets
2. **Histórico**: Integrado com sistema de histórico de uso
3. **Programa**: Botão "Usar" insere diretamente no programa
4. **Data**: Sincronizado com campo de data do programa

### Atualização Automática

- Sugestões são recalculadas ao mudar para a aba
- Respeita a data selecionada no programa
- Atualiza informação litúrgica automaticamente

---

## 📊 Estrutura de Dados

### Campos do Catálogo Usados
```javascript
{
  Título: string,      // Nome do cântico
  Autor: string,       // Compositor/autor
  Secção: string,      // Entrada, Comunhão, etc.
  Tempo: string,       // Advento, Natal, Quaresma, etc.
  Tags: string,        // Tags adicionais (cores, temas)
  Letra: string        // Letra completa (opcional)
}
```

### Objeto de Sugestão
```javascript
{
  song: Object,        // Objeto completo do cântico
  score: Number        // Pontuação de relevância (0-100+)
}
```

---

## 🎯 Como Usar

### 1. Selecionar Data
Na aba **Programa**, escolha a data da celebração.

### 2. Ir para Sugestões
Clique na aba **Sugestões** no menu de navegação.

### 3. Explorar Recomendações
- Veja as sugestões organizadas por parte do programa
- Analise o score e informação de uso recente
- Leia a letra se disponível

### 4. Adicionar ao Programa
- Clique em **"Usar"** para adicionar diretamente
- O cântico será inserido na parte correspondente
- Volta automaticamente ao programa (opcional)

---

## 🔍 Detalhes de Implementação

### Arquivos Modificados

1. **index_v24.html**
   - Nova secção HTML `<section id="tab-sugestoes">`
   - Botão na navegação
   - Estilos CSS para interface de sugestões

2. **scripts/scripts.js**
   - `scoreSongForContext()` - Sistema de pontuação
   - `buildSuggestionsForDay()` - Construtor de sugestões
   - `renderDailySuggestions()` - Renderização da interface
   - `useSuggestionInProgram()` - Inserção no programa
   - `viewSongLyrics()` - Modal de visualização de letra

### CSS Adicionado
- `.suggestions-part` - Container de cada parte
- `.suggestion-card` - Cartão individual de sugestão
- `.suggestion-score` - Badge de pontuação
- `.suggestion-usage` - Indicador de uso recente

---

## 🚀 Melhorias Futuras Possíveis

1. **Filtros de Sugestões**
   - Filtrar por score mínimo
   - Filtrar por uso recente
   - Filtrar por autor

2. **Personalização**
   - Ajustar pesos do sistema de pontuação
   - Preferências de cânticos por celebração
   - Lista de favoritos

3. **Estatísticas**
   - Cânticos mais usados por tempo litúrgico
   - Análise de variedade do repertório
   - Sugestões baseadas em histórico da comunidade

4. **Inteligência Avançada**
   - Machine learning baseado em escolhas anteriores
   - Sugestões baseadas em tom/tonalidade
   - Compatibilidade entre cânticos do programa

---

## 📝 Notas de Compatibilidade

✅ **Mantido da V22:**
- Todo o design visual original
- Sistema de cores litúrgicas
- Funcionalidade de drag-and-drop
- Gestão de ensaios
- Histórico de programas
- Integração com Google Sheets
- Exportação para PDF

✅ **Compatível com:**
- Navegadores modernos (Chrome, Firefox, Safari, Edge)
- Dispositivos móveis e tablets
- Modo de impressão existente

---

## 🐛 Resolução de Problemas

### Sugestões não aparecem
- Verifique se uma data está selecionada
- Confirme que o catálogo está carregado
- Atualize a aba clicando novamente

### Scores muito baixos
- Verifique as tags do catálogo
- Confirme que os campos Secção e Tempo estão preenchidos
- Ajuste os pesos no código se necessário

### Uso recente não aparece
- Verifique se o histórico está a ser guardado
- Confirme localStorage está ativo no navegador

---

## 📞 Suporte

Para questões ou melhorias, consulte a documentação principal ou contacte o desenvolvedor.

**Versão:** 24  
**Data:** Novembro 2024  
**Coro:** São João Batista de Rio Caldo
