# 🚀 Guia de Instalação Rápida - V24

## Passos para Atualizar da V22 para V24

### 1️⃣ Fazer Backup
```
⚠️ IMPORTANTE: Guarde uma cópia da sua versão atual antes de atualizar!
```

### 2️⃣ Extrair Arquivos
Extraia o ficheiro `site_coral_v24_completo.zip` que contém:
```
site_coral_v24_completo.zip
├── index_v24.html
└── scripts/
    └── scripts.js
```

### 3️⃣ Estrutura de Ficheiros
Organize os ficheiros assim:
```
[pasta_do_site]/
├── index.html          (renomeie index_v24.html para index.html)
└── scripts/
    └── scripts.js
```

### 4️⃣ Configurar Google Sheets
Certifique-se que a sua sheet está publicada. No código, localize esta linha em `scripts.js`:

```javascript
const SHEET_CSV_URL = 'SUA_URL_AQUI';
```

### 5️⃣ Testar Localmente
Abra o `index.html` num navegador para testar:
- ✓ Catálogo carrega
- ✓ Data pode ser selecionada
- ✓ Aba Sugestões aparece
- ✓ Sugestões são geradas

### 6️⃣ Fazer Deploy
Faça upload para o seu serviço de hosting:
- Netlify
- GitHub Pages
- Vercel
- Surge.sh
- etc.

---

## 🎯 Primeiros Passos Após Instalação

### 1. Verificar Catálogo
- Vá para **Catálogo**
- Clique em **"Atualizar catálogo agora"**
- Confirme que os cânticos aparecem

### 2. Testar Programa
- Vá para **Programa**
- Selecione uma data
- Adicione alguns cânticos

### 3. Explorar Sugestões
- Vá para **Sugestões**
- Veja as recomendações automáticas
- Experimente clicar em **"Usar"**

---

## 🔧 Configurações Opcionais

### Ajustar Pesos de Pontuação
Em `scripts.js`, função `scoreSongForContext()`:

```javascript
// Adequação da secção (padrão: 40)
if (secao.includes(partLabel)) {
  score += 40;  // ← Ajuste aqui
}

// Tempo litúrgico (padrão: 25)
if (tempo.includes(season)) {
  score += 25;  // ← Ajuste aqui
}
```

### Alterar Número de Sugestões
Em `scripts.js`, função `buildSuggestionsForDay()`:

```javascript
// Pega os top 3 (mude para 2, 4, 5...)
suggestions[part.id] = scored.slice(0, 3);
                                    // ↑
```

---

## 📱 Compatibilidade

### Navegadores Suportados
✅ Chrome 90+  
✅ Firefox 88+  
✅ Safari 14+  
✅ Edge 90+  
✅ Mobile browsers

### Requisitos
- JavaScript ativado
- localStorage disponível
- Ligação à internet (para Google Sheets)

---

## 🆘 Problemas Comuns

### "Sugestões não aparecem"
**Solução:** Selecione uma data no Programa primeiro.

### "Catálogo vazio"
**Solução:** Verifique URL do Google Sheets e permissões.

### "Histórico perdido"
**Solução:** localStorage foi limpo. Histórico não é recuperável.

### "Layout quebrado"
**Solução:** Certifique-se que `scripts/scripts.js` está no caminho correto.

---

## 📊 Estrutura do Google Sheets

Seu Google Sheets deve ter estas colunas (mínimo):
```
Título | Autor | Secção | Tempo | Tags | Letra
```

**Exemplo:**
```
Vinde, Cantai | J. Silva | Entrada | Advento | aleluia,alegria | [letra aqui]
```

---

## 🎨 Personalização de Cores

As cores litúrgicas já estão configuradas:
- **Advento/Quaresma:** Roxo
- **Natal/Páscoa:** Branco/Dourado
- **Tempo Comum:** Verde

Para alterar, edite no CSS do `index_v24.html`:
```css
body.liturgic-advento,
body.liturgic-quaresma {
  --header-bg: #4b2c6f;  /* ← Sua cor aqui */
}
```

---

## ✅ Checklist de Instalação

- [ ] Backup da versão anterior feito
- [ ] Arquivos extraídos corretamente
- [ ] Google Sheets URL configurada
- [ ] Site testado localmente
- [ ] Deploy feito com sucesso
- [ ] Catálogo carrega sem erros
- [ ] Sugestões funcionam
- [ ] Histórico preservado (se aplicável)

---

## 📞 Suporte

Se encontrar problemas:
1. Verifique a consola do navegador (F12)
2. Confirme que todos os ficheiros estão no lugar certo
3. Teste com uma data diferente
4. Limpe cache do navegador

---

**Boa sorte com a V24! 🎵**
