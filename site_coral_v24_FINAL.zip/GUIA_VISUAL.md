# 🎨 Guia Visual - Aba Sugestões V24

## 📸 Como Fica a Nova Aba

### Cabeçalho Litúrgico
```
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║  Data: 25/11/2024                                            ║
║  Celebração: XXXIV Domingo do Tempo Comum — Ano B           ║
║  Tempo: Tempo Comum    Cor: Verde    Ano: B                 ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

### Exemplo 1: Sugestões para Entrada
```
┌─────────────────────────────────────────────────────────────┐
│ 🎉 Entrada                                                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Vinde, Cantai ao Senhor                             │   │
│ │ 🎵 J. Silva                                         │   │
│ │ 📂 Entrada                                          │   │
│ │ 📅 Tempo Comum                                      │   │
│ │ Score: 65  •  Usado há 2 meses                     │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Louvai ao Senhor                                    │   │
│ │ 🎵 M. Costa                                         │   │
│ │ 📂 Entrada, Final                                   │   │
│ │ 📅 Geral                                            │   │
│ │ Score: 55  •  Usado há 4 meses                     │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Aclamai o Senhor                                    │   │
│ │ 🎵 P. Santos                                        │   │
│ │ 📂 Entrada                                          │   │
│ │ 📅 Festas                                           │   │
│ │ Score: 50  •  Usado há 6 meses                     │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### Exemplo 2: Sugestões para Comunhão
```
┌─────────────────────────────────────────────────────────────┐
│ 🍞 Comunhão                                                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Cordeiro de Deus                                    │   │
│ │ 🎵 Anónimo                                          │   │
│ │ 📂 Comunhão                                         │   │
│ │ 📅 Geral                                            │   │
│ │ Score: 70  •  Usado há 5 semanas                   │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Eu Vim para Servir                                  │   │
│ │ 🎵 M. Faria                                         │   │
│ │ 📂 Comunhão                                         │   │
│ │ 📅 Geral, Quaresma                                  │   │
│ │ Score: 45                                           │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎨 Cores e Indicadores

### Score (Pontuação)
```
┌──────────────┐
│ Score: 85    │  ← Azul claro: Alta relevância
└──────────────┘

┌──────────────┐
│ Score: 55    │  ← Azul: Relevância média
└──────────────┘

┌──────────────┐
│ Score: 25    │  ← Azul: Baixa relevância
└──────────────┘
```

### Uso Recente
```
┌──────────────────────┐
│ Usado há 2 semanas   │  ← Vermelho: Muito recente (penalizado)
└──────────────────────┘

┌──────────────────────┐
│ Usado há 2 meses     │  ← Verde: Uso normal
└──────────────────────┘

┌──────────────────────┐
│ Usado há 8 meses     │  ← Verde: Há muito tempo
└──────────────────────┘
```

---

## 📋 Exemplo Completo: Domingo de Páscoa

```
╔═══════════════════════════════════════════════════════════════╗
║  💡 Sugestões inteligentes                                    ║
╚═══════════════════════════════════════════════════════════════╝

┌───────────────────────────────────────────────────────────────┐
│ Data: 31/03/2024                                              │
│ Celebração: Domingo de Páscoa da Ressurreição do Senhor      │
│ Tempo: Páscoa    Cor: Branco    Ano: B                       │
└───────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ 🎉 Entrada                                                  │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Aleluia, Cristo Ressuscitou                         │   │
│ │ 🎵 C. Silva  📂 Entrada  📅 Páscoa                  │   │
│ │ Score: 90  •  Usado há 1 ano                       │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Ressuscitou o Senhor                                │   │
│ │ 🎵 Tradicional  📂 Entrada  📅 Páscoa               │   │
│ │ Score: 85                                           │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ 📜 Aclamação ao Evangelho                                   │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Aleluia Pascal                                      │   │
│ │ 🎵 Litúrgico  📂 Aclamação  📅 Páscoa               │   │
│ │ Score: 95  •  Usado há 1 ano                       │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ 🍞 Comunhão                                                 │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Cristo Ressuscitou                                  │   │
│ │ 🎵 M. Faria  📂 Comunhão  📅 Páscoa                 │   │
│ │ Score: 80  •  Usado há 11 meses                    │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Vida Nova                                           │   │
│ │ 🎵 P. Santos  📂 Comunhão  📅 Páscoa, Baptismo      │   │
│ │ Score: 70                                           │   │
│ │                                      [Usar] [Letra] │   │
│ └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Interações do Utilizador

### 1. Ver Letra
```
Clique em [Letra] → Abre modal com letra completa
┌──────────────────────────────────────┐
│ Aleluia, Cristo Ressuscitou          │
├──────────────────────────────────────┤
│                                      │
│ Aleluia, aleluia, aleluia!          │
│ Cristo ressuscitou, venceu a morte  │
│ Aleluia, aleluia!                    │
│                                      │
│ Cristo vive entre nós...             │
│                                      │
│                          [Fechar]    │
└──────────────────────────────────────┘
```

### 2. Usar no Programa
```
Clique em [Usar] → Adiciona ao programa
                ↓
✓ "Aleluia, Cristo Ressuscitou" adicionado a Entrada
```

---

## 🔍 Detalhes Visuais

### Cores do Tema
- **Fundo dos cartões:** Cinza claro / Azul escuro (dark mode)
- **Bordas:** Cinza subtil
- **Score:** Azul claro com texto azul escuro
- **Uso recente:** Verde (ok) / Vermelho (alerta)
- **Botões:** Azul primário / Cinza secundário

### Ícones Usados
- 🎉 Entrada
- 🙏 Ato Penitencial
- 🎶 Glória
- 📖 Salmo
- 📜 Aclamação
- 🎁 Ofertório
- ✨ Santo
- 🤲 Pai Nosso
- 🕊️ Paz
- 🐑 Cordeiro
- 🍞 Comunhão
- 🙌 Ação de Graças
- 🚪 Final

### Responsividade
```
Desktop (>768px):
- Cartões em coluna única
- Informação completa visível
- Botões lado a lado

Mobile (<768px):
- Stack vertical dos elementos
- Informação condensada
- Botões em coluna se necessário
```

---

## 💡 Dicas de UX

1. **Score alto = mais relevante**
   - 80-100: Excelente match
   - 60-79: Boa opção
   - 40-59: Aceitável
   - <40: Menos adequado

2. **Uso recente**
   - Vermelho: usado recentemente (considere variar)
   - Verde: tempo razoável desde último uso
   - Sem indicador: nunca usado ou há muito tempo

3. **Botão "Usar"**
   - Adiciona diretamente ao programa
   - Regista uso automaticamente
   - Mostra confirmação visual

4. **Botão "Ver letra"**
   - Só aparece se letra disponível
   - Abre em modal sobreposto
   - Scroll se letra for muito longa

---

## 📱 Vista Mobile

```
┌─────────────────────────┐
│ 💡 Sugestões           │
│                         │
│ Data: 25/11/2024       │
│ Tempo Comum • Ano B     │
│                         │
│ ─────────────────────   │
│                         │
│ 🎉 Entrada             │
│                         │
│ ┌─────────────────────┐ │
│ │ Vinde, Cantai       │ │
│ │ J. Silva            │ │
│ │ Score: 65           │ │
│ │ [Usar] [Letra]      │ │
│ └─────────────────────┘ │
│                         │
│ ┌─────────────────────┐ │
│ │ Louvai ao Senhor    │ │
│ │ M. Costa            │ │
│ │ Score: 55           │ │
│ │ [Usar] [Letra]      │ │
│ └─────────────────────┘ │
│                         │
└─────────────────────────┘
```

---

**A interface foi desenhada para ser limpa, funcional e intuitiva! 🎨**
